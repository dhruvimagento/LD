<?php

namespace IFlair\RecentProducts\Observer\Product;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Data implements ObserverInterface
{
	public function execute(Observer $observer)
	{
	    $product = $observer->getProduct();
	    $originalName = $product->getName();
	    $sku = $product->getSku();
	    
	    $catid = $product->getCategoryId();
	    $entid = $product->getEntityId();

	    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();	
		$SessionCollection =  $objectManager->get('IFlair\RecentProducts\Session\ProductData');		
		
		$items = array();		
		$items = $SessionCollection->getValue();	
		if($items && !in_array($sku, $items))
		{			
			array_push($items, $sku);
			$SessionCollection->setValue($items);								
		}
		else
		{	
			$items = explode(' ', $sku);			
			$SessionCollection->setValue($items);			
		}	
		dd($items);	
    }
}