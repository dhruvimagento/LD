<?php

namespace IFlair\RecentProducts\Observer\Product;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Data implements ObserverInterface
{

	public function execute(Observer $observer)
	{
	    $product = $observer->getProduct();
	    $originalName = $product->getName();
	    $sku = $product->getSku();
	    $imgdata = $product->getImage();
	    $catid = $product->getCategoryId();
	    $entid = $product->getEntityId();

	    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

		/*-------begining of code to set data to session----------*/
		$SessionCollection =  $objectManager->get('IFlair\RecentProducts\Session\ProductData');		
		//dd($SessionCollection);
		$skus1 = array();
		if($skus[] = $SessionCollection->getValue())
		{
			echo "string";
			$skus1 = $skus[];
			$skus1 = $sku; 
			$SessionCollection->setValue($sku);
		}
		else
		{
			echo "string11";
			$skus1 = $SessionCollection->setValue($sku);
		}
		dd($skus1);
		$value = $SessionCollection->setValue($skus);
		//dd($SessionCollection->getValue());
		$a  = $SessionCollection->getValue();		
		//$newValue = explode(",",$value);
		$items = array();
		die("scsd");
		foreach ($a as $values) {	
			echo $values;		
	        $items[] = $values;
	    }
	    /*if($value)
	    {
	        if(!in_array($entid,$newValue))
	        {
	            $newdata = $value.",".$entid;
	            $SessionCollection->setValue($newdata);
	        }
	        
	       	//$SessionCollection->setValue($entid);
	    }
	    else
	    {
	        $SessionCollection->setValue($entid);
	    }*/
	    dd($items);
	    print_r($items); exit;
	    /*print_r($value);
	    dd($value);    	*/
    }
}